#include <linux/kernel.h>
#include <linux/errno.h>
#include <crypto/pkcs7.h>

extern const char __initconst *const blacklist_hashes[];

.. SPDX-License-Identifier: GPL-2.0

====================
Intel StrongARM 1100
====================

.. toctree::
    :maxdepth: 1

    assabet
    cerf
    lart
    serial_uart

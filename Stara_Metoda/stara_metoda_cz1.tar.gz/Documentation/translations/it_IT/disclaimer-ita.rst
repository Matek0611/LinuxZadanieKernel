:orphan:

.. warning::
   In caso di dubbi sulla correttezza del contenuto di questa traduzione,
   l'unico riferimento valido è la documentazione ufficiale in inglese.
   Per maggiori informazioni consultate le :ref:`avvertenze <it_disclaimer>`.

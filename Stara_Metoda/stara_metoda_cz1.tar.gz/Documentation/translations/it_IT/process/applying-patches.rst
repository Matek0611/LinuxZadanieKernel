.. include:: ../disclaimer-ita.rst

:Original: :ref:`Documentation/process/applying-patches.rst <applying_patches>`
:Translator: Federico Vaga <federico.vaga@vaga.pv.it>

.. _it_applying_patches:

Applicare patch al kernel Linux
+++++++++++++++++++++++++++++++

.. note::

   Questo documento è obsoleto.  Nella maggior parte dei casi, piuttosto
   che usare ``patch`` manualmente, vorrete usare Git.  Per questo motivo
   il documento non verrà tradotto.

.. include:: ../disclaimer-ita.rst

:Original: :ref:`Documentation/process/submitting-drivers.rst <submittingdrivers>`
:Translator: Federico Vaga <federico.vaga@vaga.pv.it>

.. _it_submittingdrivers:

Sottomettere driver per il kernel Linux
=======================================

.. note::

   Questo documento è vecchio e negli ultimi anni non è stato più aggiornato;
   dovrebbe essere aggiornato, o forse meglio, rimosso.  La maggior parte di
   quello che viene detto qui può essere trovato anche negli altri documenti
   dedicati allo sviluppo.  Per questo motivo il documento non verrà tradotto.

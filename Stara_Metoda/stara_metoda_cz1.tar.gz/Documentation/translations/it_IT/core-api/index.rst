===============================
Documentazione dell'API di base
===============================

Utilità di base
===============

.. toctree::
   :maxdepth: 1

   symbol-namespaces

.. only:: subproject and html

   Indices
   =======

   * :ref:`genindex`

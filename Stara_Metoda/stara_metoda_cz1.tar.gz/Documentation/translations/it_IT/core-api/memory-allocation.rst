.. include:: ../disclaimer-ita.rst

:Original: :ref:`Documentation/core-api/memory-allocation.rst <memory_allocation>`

.. _it_memory_allocation:

================================
Guida all'allocazione di memoria
================================

.. warning::

    TODO ancora da tradurre

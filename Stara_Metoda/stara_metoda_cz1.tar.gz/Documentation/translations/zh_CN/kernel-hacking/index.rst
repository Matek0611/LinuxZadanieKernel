.. _kernel_hacking_zh:

.. include:: ../disclaimer-zh_CN.rst

:Original: Documentation/kernel-hacking/index.rst

:译者:

 吴想成 Wu XiangCheng <bobwxc@email.cn>

=============
内核骇客指南
=============

.. toctree::
   :maxdepth: 2

   hacking

TODO

- locking

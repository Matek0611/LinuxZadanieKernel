.. include:: ../disclaimer-zh_CN.rst

:Original: Documentation/infiniband/sysfs.rst

:翻译:

 司延腾 Yanteng Si <siyanteng@loongson.cn>

:校译:

 王普宇 Puyu Wang <realpuyuwang@gmail.com>
 时奎亮 Alex Shi <alexs@kernel.org>

.. _cn_infiniband_sysfs:

=========
Sysfs文件
=========

sysfs接口已移至
Documentation/ABI/stable/sysfs-class-infiniband.

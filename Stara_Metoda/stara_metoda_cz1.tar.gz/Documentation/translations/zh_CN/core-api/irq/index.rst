.. include:: ../../disclaimer-zh_CN.rst

:Original: Documentation/core-api/irq/index.rst

:翻译:

 司延腾 Yanteng Si <siyanteng@loongson.cn>

.. _cn_irq_index.rst:


====
IRQs
====

.. toctree::
   :maxdepth: 1

   concepts
   irq-affinity
   irq-domain
   irqflags-tracing

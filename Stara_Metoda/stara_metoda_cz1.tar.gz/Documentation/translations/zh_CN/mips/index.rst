.. SPDX-License-Identifier: GPL-2.0

.. include:: ../disclaimer-zh_CN.rst

:Original: Documentation/mips/index.rst

:翻译:

 司延腾 Yanteng Si <siyanteng@loongson.cn>

===========================
MIPS特性文档
===========================

.. toctree::
   :maxdepth: 2
   :numbered:

   booting
   ingenic-tcu

   features

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`

.. SPDX-License-Identifier: GPL-2.0

.. include:: ../disclaimer-zh_CN.rst

:Original: Documentation/mips/features.rst

:翻译:

 司延腾 Yanteng Si <siyanteng@loongson.cn>

.. _cn_features:

.. kernel-feat:: $srctree/Documentation/features mips

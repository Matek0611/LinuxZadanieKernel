.. SPDX-License-Identifier: GPL-2.0-only
.. include:: ../disclaimer-zh_CN.rst

:Original: Documentation/peci/index.rst

:翻译:

 司延腾 Yanteng Si <siyanteng@loongson.cn>

:校译:

=================
Linux PECI 子系统
=================

.. toctree::


   peci

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`

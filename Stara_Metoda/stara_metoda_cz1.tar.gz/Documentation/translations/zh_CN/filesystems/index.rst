.. SPDX-License-Identifier: GPL-2.0

.. include:: ../disclaimer-zh_CN.rst

:Original: :ref:`Documentation/filesystems/index.rst <filesystems_index>`
:Translator: Wang Wenhu <wenhu.wang@vivo.com>

.. _cn_filesystems_index:

========================
Linux Kernel中的文件系统
========================

这份正在开发的手册或许在未来某个辉煌的日子里以易懂的形式将Linux虚拟\
文件系统（VFS）层以及基于其上的各种文件系统如何工作呈现给大家。当前\
可以看到下面的内容。

文件系统
========

文件系统实现文档。

.. toctree::
   :maxdepth: 2

   virtiofs
   debugfs
   tmpfs


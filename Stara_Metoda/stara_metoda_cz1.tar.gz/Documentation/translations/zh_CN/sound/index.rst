.. SPDX-License-Identifier: GPL-2.0
.. include:: ../disclaimer-zh_CN.rst

:Original: :doc:`../../../sound/index`
:Translator: Huang Jianghui <huangjianghui@uniontech.com>


====================
Linux 声音子系统文档
====================

.. toctree::
   :maxdepth: 2

   hd-audio/index

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`

.. SPDX-License-Identifier: GPL-2.0
.. include:: ../../disclaimer-zh_CN.rst

:Original: :doc:`../../../../sound/hd-audio/index`
:Translator: Huang Jianghui <huangjianghui@uniontech.com>


高清音频
========

.. toctree::
   :maxdepth: 2

   controls

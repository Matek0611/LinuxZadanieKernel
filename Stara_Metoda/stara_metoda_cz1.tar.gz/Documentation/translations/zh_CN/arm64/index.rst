.. include:: ../disclaimer-zh_CN.rst

:Original: :ref:`Documentation/arm64/index.rst <arm64_index>`
:Translator: Bailu Lin <bailu.lin@vivo.com>

.. _cn_arm64_index:


==========
ARM64 架构
==========

.. toctree::
    :maxdepth: 2

    amu
    hugetlbpage
    perf
    elf_hwcaps

.. raw:: latex

	\renewcommand\thesection*
	\renewcommand\thesubsection*
	\kerneldocCJKon
	\kerneldocBeginKR{

한국어 번역
===========

.. toctree::
   :maxdepth: 1

   howto


리눅스 커널 메모리 배리어
-------------------------

.. raw:: latex

    \footnotesize

.. include:: ./memory-barriers.txt
    :literal:

.. raw:: latex

    }\kerneldocEndKR

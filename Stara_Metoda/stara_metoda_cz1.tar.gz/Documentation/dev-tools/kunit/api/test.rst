.. SPDX-License-Identifier: GPL-2.0

========
Test API
========

This file documents all of the standard testing API.

.. kernel-doc:: include/kunit/test.h
   :internal:

.. include:: ../disclaimer-ita.rst

:Original: :ref:`Documentation/admin-guide/kernel-parameters.rst <kernelparameters>`

.. _it_kernelparameters:

I parametri da linea di comando del kernel
==========================================

.. warning::

    TODO ancora da tradurre

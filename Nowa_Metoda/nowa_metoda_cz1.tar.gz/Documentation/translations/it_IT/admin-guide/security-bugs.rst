.. include:: ../disclaimer-ita.rst

:Original: :ref:`Documentation/admin-guide/security-bugs.rst <securitybugs>`

.. _it_securitybugs:

Bachi di sicurezza
==================

.. warning::

    TODO ancora da tradurre

.. include:: ../disclaimer-ita.rst

:Original: :ref:`Documentation/admin-guide/README.rst <readme>`

.. _it_readme:

Rilascio del kernel Linux  5.x <http://kernel.org/>
===================================================

.. warning::

    TODO ancora da tradurre

.. include:: ../disclaimer-ita.rst

:Original: :ref:`Documentation/process/code-of-conduct.rst <code_of_conduct>`

.. _it_code_of_conduct:

Accordo dei contributori sul codice di condotta
+++++++++++++++++++++++++++++++++++++++++++++++

.. warning::

    TODO ancora da tradurre

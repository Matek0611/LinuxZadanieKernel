.. include:: ../disclaimer-ita.rst

:Original: :ref:`Documentation/networking/netdev-FAQ.rst <netdev-FAQ>`

.. _it_netdev-FAQ:

==========
netdev FAQ
==========

.. warning::

    TODO ancora da tradurre

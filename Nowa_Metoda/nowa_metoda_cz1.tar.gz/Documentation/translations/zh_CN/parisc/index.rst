.. SPDX-License-Identifier: GPL-2.0
.. include:: ../disclaimer-zh_CN.rst

:Original: Documentation/parisc/index.rst

:翻译:

 司延腾 Yanteng Si <siyanteng@loongson.cn>

.. _cn_parisc_index:

====================
PA-RISC体系架构
====================

.. toctree::
   :maxdepth: 2

   debugging
   registers

Todolist:

   features

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`

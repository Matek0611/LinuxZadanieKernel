.. include:: ../disclaimer-zh_CN.rst

:Original: Documentation/doc-guide/index.rst

:译者: 吴想成 Wu XiangCheng <bobwxc@email.cn>

.. _doc_guide_zh:

================
如何编写内核文档
================

.. toctree::
   :maxdepth: 1

   sphinx
   kernel-doc
   parse-headers
   contributing
   maintainer-profile

.. only::  子项目与HTML

   目录
   ====

   * :ref:`genindex`

.. SPDX-License-Identifier: GPL-2.0

.. include:: ../disclaimer-zh_CN.rst

:Original: Documentation/openrisc/index.rst

:翻译:

 司延腾 Yanteng Si <siyanteng@loongson.cn>

.. _cn_openrisc_index:

=================
OpenRISC 体系架构
=================

.. toctree::
   :maxdepth: 2

   openrisc_port
   todo

Todolist:
    features


.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`

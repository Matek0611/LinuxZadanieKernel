.. raw:: latex

	\renewcommand\thesection*
	\renewcommand\thesubsection*
	\kerneldocCJKon
	\kerneldocBeginJP{

Japanese translations
=====================

.. toctree::
   :maxdepth: 1

   howto

.. raw:: latex

	}\kerneldocEndJP

.. SPDX-License-Identifier: GPL-2.0

============
i386 Support
============

.. toctree::
   :maxdepth: 2

   IO-APIC
